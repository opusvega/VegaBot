let intentLookup = {
	AgentLocator : "Finding an agent",
	FeeEstimate : "Remittance fee",
	reportatmincident : "Report ATM issue",
	trackatmincident : "Track ATM incident",
	transferinit : "Fund Transfer",
	addbiller : "Add Biller",
	billinitintent : "Bill pay",
	gasbillinitpay : "Pay Gas Bill",
	lightbillinitpay : "Pay Power Bill",
	phonebillinitpay : "Pay Phone Bill"
}

exports.intentLookup = intentLookup;