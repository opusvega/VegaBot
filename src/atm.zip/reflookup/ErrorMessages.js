let requestConfig = {
};

// Error Handling 
let ErrorMessages = {
        ERROR_RESPONE_TEXT : "Unable to retrieve the status right now, Please try after some time"
};

exports.ErrorMessages = ErrorMessages;