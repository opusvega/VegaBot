let requestConfig = {
};

let RemitProducts = {
        ProductWithCCorCash : {
                "DIRECT TO BANK" : "0-1 Business Days",
                "INSTANT MONEY TRANSFER" : "In Minutes",
                "MONEY TRANSFER NEXT DAY" : "Next Day",
        },
        ProductWithBankACH : {
                "DIRECT TO BANK" : "0-1 Business Days",
                "INSTANT MONEY TRANSFER" : "In Minutes",
                "MONEY TRANSFER NEXT DAY" : "Next Day",
        }
};

exports.RemitProducts = RemitProducts;