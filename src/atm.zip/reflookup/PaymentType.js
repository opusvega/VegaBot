let requestConfig = {
};

let PaymentType = {
        ACH : "Bank account",
        Cash : "Cash",
        CreditCard : "Credit/debit Card"
};

exports.PaymentType = PaymentType;