AgentLocator-ShowDetails-Timing :-
	{
    "fulfillment": {
      "speech": "",
      "source": "apiai-webhook-sample",
      "displayText": "",
      "messages": [
        {
          "platform": "facebook",
          "payload": {},
          "type": 0,
          "speech": "Available timings of Agent A K TOURS AND TRAVELS : \n\nMONDAY : 7:00 AM - 9:00 PM, \nTUESDAY : 7:00 AM - 9:00 PM, \nWEDNESDAY : 7:00 AM - 9:00 PM,  \nTHURSDAY : 7:00 AM - 9:00 PM, \nFRIDAY : 7:00 AM - 9:00 PM, \nSATURDAY : 7:00 AM - 9:00 PM, \nSUNDAY : 7:00 AM - 9:00 PM, "
        },
        {
          "type": 0,
          "platform": "facebook",
          "speech": "Disclaimer :\n1. Hours of operation may vary and are subject to change without notice.\n2. Currency availability may vary by location and maximum payout limits may apply.\n3. Please contact the specific agent location for more information."
        },
        {
          "type": 0,
          "speech": "Available timings of Agent A K TOURS AND TRAVELS : \n \nMONDAY : 7:00 AM - 9:00 PM, \nTUESDAY : 7:00 AM - 9:00 PM, \nWEDNESDAY : 7:00 AM - 9:00 PM, \nTHURSDAY : 7:00 AM - 9:00 PM,  \nFRIDAY : 7:00 AM - 9:00 PM,  \nSATURDAY : 7:00 AM - 9:00 PM,  \nSUNDAY : 7:00 AM - 9:00 PM, "
        }
      ],
      "data": {
        "google": {
          "expect_user_response": true,
          "rich_response": {
            "items": [
              {
                "simpleResponse": {
                  "textToSpeech": "Available timings of Agent A K TOURS AND TRAVELS : \n \nMONDAY : 7:00 AM - 9:00 PM, \nTUESDAY : 7:00 AM - 9:00 PM, \nWEDNESDAY : 7:00 AM - 9:00 PM, \nTHURSDAY : 7:00 AM - 9:00 PM,  \nFRIDAY : 7:00 AM - 9:00 PM,  \nSATURDAY : 7:00 AM - 9:00 PM,  \nSUNDAY : 7:00 AM - 9:00 PM, "
  
                  "displayText": "Available timings of Agent A K TOURS AND TRAVELS : \n \nMONDAY : 7:00 AM - 9:00 PM, \nTUESDAY : 7:00 AM - 9:00 PM, \nWEDNESDAY : 7:00 AM - 9:00 PM, \nTHURSDAY : 7:00 AM - 9:00 PM,  \nFRIDAY : 7:00 AM - 9:00 PM,  \nSATURDAY : 7:00 AM - 9:00 PM,  \nSUNDAY : 7:00 AM - 9:00 PM, "
                }
              }
            ]
          }
        }
      }
    },
    "score": 1
}