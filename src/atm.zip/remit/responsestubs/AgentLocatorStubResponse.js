let AgentLocator = {
	"speech": "Please tell me the name of your city or zip code",
	"displayText": "Please tell me the name of your city or zip code",
	"source": "Opus-NLP"
}
exports.AgentLocator = AgentLocator;