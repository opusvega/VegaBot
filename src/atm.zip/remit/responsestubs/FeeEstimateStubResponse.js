let FeeEstimate = {
	"speech": "Do you want to estimate fee for Money Transferor Bill Pay?",
	"displayText": "Do you want to estimate fee for Money Transferor Bill Pay?",
	"source": "Opus-NLP"
}
exports.FeeEstimate = FeeEstimate;