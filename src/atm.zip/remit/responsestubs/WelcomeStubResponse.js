let WelcomeStubResponse = {
	"speech": "Welcome to Opus. My name is Vega. How can I help you?",
	"displayText": "Welcome to Opus. My name is Vega. How can I help you?",
	"source": "Opus-NLP"
}
exports.WelcomeStubResponse = WelcomeStubResponse;