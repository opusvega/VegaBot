let FeeEstimasteBillPay = {
	"speech": "Currently Bill Pay is not available. Sorry for inconvenience.",
	"displayText": "Currently Bill Pay is not available. Sorry for inconvenience.",
	"source": "Opus-NLP"
}
exports.FeeEstimasteBillPay = FeeEstimasteBillPay;