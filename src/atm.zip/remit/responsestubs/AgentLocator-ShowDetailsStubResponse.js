AgentLocator-ShowDetails :-
	{
   "fulfillment": {
      "speech": "Details of Agent A K TOURS AND TRAVELS\nDistance : 0.01mi\nAddress : Shop 3 Natasha Enclave Nibm Road Kondhva Pune 411048 Maharashtra India \nContact number : +91-20-64051044\nServices : \n\tMoney Transfer\n\nOn which day of a week would you like to visit?",
      "source": "apiai-webhook-sample",
      "displayText": "Details of Agent A K TOURS AND TRAVELS\nDistance : 0.01mi\nAddress : Shop 3 Natasha Enclave Nibm Road Kondhva Pune 411048 Maharashtra India\nContact number : +91-20-64051044\nServices : \n\tMoney Transfer\n\nOn which day of a week would you like to visit?",
      "messages": [
        {
          "type": 0,
          "id": "c0a42760-19de-4db0-96f4-c51eeabad75b",
          "speech": "Details of Agent A K TOURS AND TRAVELS\nDistance : 0.01mi\nAddress : Shop 3 Natasha Enclave Nibm Road Kondhva Pune 411048 Maharashtra India\nContact number : +91-20-64051044\nServices : \n\tMoney Transfer\n\nOn which day of a week would you like to visit?"
        }
      ]
    },
    "score": 1
}