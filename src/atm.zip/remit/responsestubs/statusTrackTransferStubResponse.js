let sampleResponseForMTCN =
{
"speech": "The status of your transfer is in-progress",
"displayText": "The status of your transfer is in-progress",
"source": "Opus-NLP"
}

exports.sampleResponseForMTCN = sampleResponseForMTCN;